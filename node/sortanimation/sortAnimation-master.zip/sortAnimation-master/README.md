# sortAnimation
**JavaScript动画展示常见排序算法 2016年6月**

演示地址：http://runningls.com/demos/2016/sortAnimation

说明：http://blog.csdn.net/liusaint1992/article/details/51656124
